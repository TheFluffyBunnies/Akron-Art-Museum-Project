x =-100;
var img;
var img1;
var img2;
var img3;
function preload() {
	img = loadImage('http://akronartmuseum.org/collection-assets/media/Previews/JPEG/1955.25.jpg');
	img1 = loadImage('https://akronartmuseum.org/collection-assets/media/Previews/JPEG/1955.38.jpg');
	img2 = loadImage('https://akronartmuseum.org/collection-assets/media/Previews/JPEG/1979.4g.jpg');
	img3 = loadImage('https://akronartmuseum.org/collection-assets/media/Previews/Other_%20PC/7_00jpgs/1992.46.jpg');
}

function setup() {
	createCanvas(windowWidth, windowHeight);
	background(0);
	
	

}

function draw() {
background(0)
	image(img, 0, 0);
	image(img1, 1070, 400);
	image(img2, 0, 400);
	image(img3, 1070, 0);
x=x+5
if (x>1400) {
	x=-100

}
	textSize(32);
	fill(255, 180, 61);
	text('AKRON',450,350);
	text('ART',450,400);
	text('MUSEUM',450,450);
	textSize(50)
	text('WELCOME TO THE',x,50);
	fill(104, 255, 229);
	//right triangle 
	triangle(870, 470, 908, 400, 936, 455);
	//lower trapezoid 
	quad(863, 501, 952, 480, 1006, 570, 825, 576);
	// lower triangle 
	triangle(765, 515, 797, 577, 831, 505);
	// top quad
	quad(710, 409, 900, 310, 829, 463, 760, 482);
	// bottom left scalene thing triangle
	triangle(510, 575, 730, 525, 756, 575);
	// bottom left scalene triangle
	triangle(530, 550, 688, 450, 720, 495);
}